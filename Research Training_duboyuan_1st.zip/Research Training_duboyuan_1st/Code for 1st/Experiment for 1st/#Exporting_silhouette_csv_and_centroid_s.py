#Exporting_silhouette_csv_and_centroid_shift_csv.py
def export_silhouette_csv(sil_tr_df: pd.DataFrame, sil_te_df: pd.DataFrame,
                          savepath="silhouette_per_class.csv"):
    df = pd.merge(sil_tr_df.rename(columns={"sil_mean":"sil_train_mean","n":"n_train"}),
                  sil_te_df.rename(columns={"sil_mean":"sil_test_mean","n":"n_test"}),
                  on="digit", how="inner").sort_values("digit").reset_index(drop=True)
    df.to_csv(savepath, index=False)
    return savepath, df

def export_centroid_shift_csv(shift_df: pd.DataFrame, savepath="centroid_shift.csv"):
    shift_df.sort_values("digit").reset_index(drop=True).to_csv(savepath, index=False)
    return savepath