#Statistic loading and data splitting and centering for sklearn digits.
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
from matplotlib.patches import Ellipse
from sklearn.datasets import load_digits
from sklearn.model_selection import train_test_split

RANDOM_STATE = 42   # 可复现实验

def load_and_split(scale_to_01: bool = True, test_size: float = 0.30, seed: int = RANDOM_STATE):
    """加载 sklearn digits，按 70/30 分层划分；返回中心化后的 (X_tr_c, X_te_c)、原始 (X_tr, X_te)、标签 (y_tr, y_te)、训练均值 mu。"""
    digits = load_digits()
    X = digits.data.astype(float)
    if scale_to_01:
        X /= 16.0
    y = digits.target
    X_tr, X_te, y_tr, y_te = train_test_split(
        X, y, test_size=test_size, random_state=seed, stratify=y
    )
    mu = X_tr.mean(axis=0)
    X_tr_c = X_tr - mu
    X_te_c = X_te - mu
    return (X_tr, X_te, y_tr, y_te, X_tr_c, X_te_c, mu)