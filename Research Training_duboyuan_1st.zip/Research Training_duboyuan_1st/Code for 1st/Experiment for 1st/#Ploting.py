#Ploting_train_with_ellipses.py
def plot_train_with_ellipses(Ztr_2d: np.ndarray, y_tr: np.ndarray,
                             title_prefix="PCA → 2D (Train solid + 90% ellipses)",
                             evr2=None, mse2d=None, savepath="pca2d_train_with_ellipses.png"):
    cmap = plt.cm.get_cmap('tab10')
    colors = [cmap(i) for i in range(10)]
    markers = ['o','s','^','v','>','<','P','*','X','D']

    fig, ax = plt.subplots(figsize=(7.4, 6.4), dpi=150)
    for d in range(10):
        idx = (y_tr == d)
        Zd = Ztr_2d[idx]
        ax.scatter(Zd[:,0], Zd[:,1], s=22, c=[colors[d]], marker=markers[d],
                   linewidths=0.0, alpha=0.9, label=f'{d}')
        if Zd.shape[0] >= 3:
            mu_d = Zd.mean(axis=0)
            S = np.cov(Zd.T)
            vals, vecs = np.linalg.eigh(S)
            chi2_q = 4.605170185988092  # 90% quantile for chi2(df=2)
            radii = np.sqrt(np.maximum(vals, 1e-12) * chi2_q)
            order = np.argsort(vals)[::-1]
            w, h = 2*radii[order[0]], 2*radii[order[1]]
            angle = np.degrees(np.arctan2(vecs[:, order[0]][1], vecs[:, order[0]][0]))
            ell = Ellipse(xy=mu_d, width=w, height=h, angle=angle, fill=False, lw=1.2, edgecolor=colors[d])
            ax.add_patch(ell)

    ax.set_xlabel("PC1"); ax.set_ylabel("PC2")
    tail = []
    if evr2 is not None: tail.append(f"EVR@2={evr2:.3f}")
    if mse2d is not None: tail.append(f"MSE2D={mse2d:.4f}")
    ax.set_title(f"{title_prefix}   |   " + "   ".join(tail))
    ax.grid(True, ls=':', lw=0.8, alpha=0.6)
    ax.legend(title="train digit", ncol=5, fontsize=8, loc='upper right', frameon=False)
    fig.tight_layout(); fig.savefig(savepath); plt.close(fig)
    return savepath