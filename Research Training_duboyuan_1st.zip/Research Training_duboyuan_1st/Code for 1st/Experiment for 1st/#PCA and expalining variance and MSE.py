PCA and expalining variance and MSE
from sklearn.decomposition import PCA

def fit_pca_k(Xc_train: np.ndarray, k: int = 2):
#Fit PCA(k) on the centralized matrix of the training set and return the pca object.
pca = PCA(n_components=k, svd_solver='full')
pca.fit(Xc_train)
return pca

def project(pca: PCA, Xc: np.ndarray):
#Project the centralized Xc onto the fitted PCA subspace.
    return pca.transform(Xc)

def cevr_at_k(pca: PCA) -> float:
#Cumulative explained variance ratio (sum of fitted k dimensions).
    return float(pca.explained_variance_ratio_.sum())

def mse2d_on_test(pca_2d: PCA, X_test: np.ndarray) -> float:
   #Reconstruct the test set using 2D PCA and calculate MSE. Note: X_test uses the original data (without mean subtraction), and inverse_transform will automatically add back the mean.
    Z_te = pca_2d.transform(X_test - pca_2d.mean_)   # 也可直接 pca_2d.transform(Xc_te)
    Xte_hat = pca_2d.inverse_transform(Z_te)
    return float(np.mean((X_test - Xte_hat) ** 2))

def cevr_curve(Xc_train: np.ndarray):
    #Using full PCA for fitting, the cumulative variance curve and the corresponding k value for the threshold are obtained.
    pca_full = PCA(svd_solver='full').fit(Xc_train)
    evr = pca_full.explained_variance_ratio_
    cevr = np.cumsum(evr)
    return cevr, pca_full