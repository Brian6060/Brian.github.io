#Ploting_per_class_silihouette_bars.py
def plot_per_class_silhouette_bars(sil_tr_df: pd.DataFrame, sil_te_df: pd.DataFrame,
                                   savepath="silhouette_per_class.png"):

    df = pd.merge(sil_tr_df.rename(columns={"sil_mean":"sil_train_mean","n":"n_train"}),
                  sil_te_df.rename(columns={"sil_mean":"sil_test_mean","n":"n_test"}),
                  on="digit", how="inner").sort_values("digit").reset_index(drop=True)
    x = np.arange(len(df))
    width = 0.38
    fig, ax = plt.subplots(figsize=(8.4, 4.6), dpi=150)
    ax.bar(x - width/2, df["sil_train_mean"], width, label='train')
    ax.bar(x + width/2, df["sil_test_mean"], width, label='test')
    ax.set_xticks(x); ax.set_xticklabels(df["digit"].astype(str).tolist())
    ax.set_ylabel('Average silhouette'); ax.set_xlabel('Digit cluster')
    ax.set_title('Per-class average silhouette in 2D'); ax.legend()
    ax.grid(True, axis='y', ls=':', lw=0.8, alpha=0.6)
    fig.tight_layout(); fig.savefig(savepath); plt.close(fig)
    return savepath, df