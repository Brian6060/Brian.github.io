#evaluating
from sklearn.metrics import silhouette_score, silhouette_samples

def silhouette_dataset(Z_2d: np.ndarray, y: np.ndarray) -> float:
    """2D 投影上的整体轮廓系数（把数字当作聚类标签）。"""
    return float(silhouette_score(Z_2d, y, metric='euclidean'))

def silhouette_per_class(Z_2d: np.ndarray, y: np.ndarray) -> pd.DataFrame:
    """每一类的平均轮廓系数与样本规模。"""
    s_all = silhouette_samples(Z_2d, y, metric='euclidean')
    rows = []
    for d in np.unique(y):
        rows.append({
            "digit": int(d),
            "sil_mean": float(s_all[y==d].mean()),
            "n": int((y==d).sum())
        })
    return pd.DataFrame(rows).sort_values("digit").reset_index(drop=True)

def centroid_shift_per_class(Ztr_2d: np.ndarray, y_tr: np.ndarray,
                             Zte_2d: np.ndarray, y_te: np.ndarray) -> pd.DataFrame:
    """每类训练/测试质心在 PC 平面上的 L2 距离以及样本数。"""
    rows = []
    for d in sorted(set(y_tr.tolist()) | set(y_te.tolist())):
        ctr = Ztr_2d[y_tr==d].mean(axis=0)
        cte = Zte_2d[y_te==d].mean(axis=0)
        rows.append({
            "digit": int(d),
            "shift_L2": float(np.linalg.norm(ctr - cte)),
            "train_n": int((y_tr==d).sum()),
            "test_n": int((y_te==d).sum())
        })
    return pd.DataFrame(rows).sort_values("digit").reset_index(drop=True)