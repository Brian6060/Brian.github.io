#Ploting_overlay_test.py
def plot_overlay_test(Ztr_2d: np.ndarray, y_tr: np.ndarray,
                      Zte_2d: np.ndarray, y_te: np.ndarray,
                      evr2=None, sil_test=None, savepath="pca2d_overlay_v3.png"):
    markers = ['o','s','^','v','>','<','P','*','X','D']

    fig, ax = plt.subplots(figsize=(7.4, 6.4), dpi=150)
    for d in range(10):
        idx = (y_tr == d)
        ax.scatter(Ztr_2d[idx,0], Ztr_2d[idx,1], s=18, c='#aaaaaa',
                   marker=markers[d], linewidths=0.0, alpha=0.25)
    for d in range(10):
        idx = (y_te == d)
        ax.scatter(Zte_2d[idx,0], Zte_2d[idx,1], s=26, facecolors='none',
                   marker=markers[d], linewidths=0.9, alpha=1.0, label=f'{d}')

    ax.set_xlabel("PC1"); ax.set_ylabel("PC2")
    tail = []
    if evr2 is not None: tail.append(f"EVR@2={evr2:.3f}")
    if sil_test is not None: tail.append(f"Sil(test)={sil_test:.3f}")
    ax.set_title("PCA → 2D (Overlay test: same-marker hollow)   |   " + "   ".join(tail))
    ax.grid(True, ls=':', lw=0.8, alpha=0.6)
    ax.legend(title="test digit", ncol=5, fontsize=8, loc='upper right', frameon=False)
    fig.tight_layout(); fig.savefig(savepath); plt.close(fig)
    return savepath