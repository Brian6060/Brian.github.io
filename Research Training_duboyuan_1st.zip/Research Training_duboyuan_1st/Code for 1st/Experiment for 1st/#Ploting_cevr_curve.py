#Ploting_cevr_curve.py
def plot_cevr_curve(cevr: np.ndarray, savepath="pca_cum_evr.png"):

    fig, ax = plt.subplots(figsize=(7.2, 4.8), dpi=150)
    ax.plot(np.arange(1, len(cevr)+1), cevr, marker='o', lw=1.25)
    ax.axvline(2, ls='--')
    ax.set_xlabel('Number of components (k)')
    ax.set_ylabel('Cumulative explained variance ratio')
    ax.set_title('PCA cumulative explained variance ratio (train)')
    ax.grid(True, ls=':', lw=0.8, alpha=0.6)
    fig.tight_layout(); fig.savefig(savepath); plt.close(fig)
    return savepath